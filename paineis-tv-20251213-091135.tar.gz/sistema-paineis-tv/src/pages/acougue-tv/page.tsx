import React from 'react';
import { ButcherTVPage } from '../butcher/ButcherTVPage';

export default function AcougueTVPage() {
  return <ButcherTVPage />;
}