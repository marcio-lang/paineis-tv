import React from 'react';
import { PanelsPage } from '../panels/PanelsPage';

export default function PaineisPage() {
  console.log('PaineisPage: Wrapper executado');
  return <PanelsPage />;
}