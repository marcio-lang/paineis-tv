import React from 'react';
import { ActionsPage } from '../actions/ActionsPage';

export default function AcoesPage() {
  return <ActionsPage />;
}