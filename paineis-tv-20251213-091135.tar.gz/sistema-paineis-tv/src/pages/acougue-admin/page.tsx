import React from 'react';
import { ButcherAdminPage } from '../butcher/ButcherAdminPage';

export default function AcougueAdminPage() {
  return <ButcherAdminPage />;
}